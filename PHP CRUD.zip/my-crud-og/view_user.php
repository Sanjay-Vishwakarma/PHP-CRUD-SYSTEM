<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <h2>View User</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>EMAIL</th>
                    <th>PASSWORD</th>
                    <th>IMAGE</th>
                    <th>DETAILS</th>
                    <th>DELETE</th>
                    <th>EDIT</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'config.php';
                $select = "SELECT * FROM user";
                $query = mysqli_query($conn, $select);
                while ($row_user = mysqli_fetch_array($query)) {


                    $u_id = $row_user['user_id'];
                    $u_name = $row_user['user_name'];
                    $u_email = $row_user['user_email'];
                    $u_password = $row_user['user_password'];
                    $u_image = $row_user['user_image'];
                    $u_details = $row_user['user_details'];
                ?>
                    <tr>
                        <td><?php echo $u_id;  ?></td>
                        <td><?php echo $u_name;  ?></td>
                        <td><?php echo $u_email;  ?></td>
                        <td><?php echo $u_password;  ?></td>
                        <td> <img src="upload/<?php echo $u_image;  ?>" height="50px"></td>
                        <td><?php echo $u_details;  ?></td>
                        <td><a href="delete_user.php?del=<?php echo $u_id;  ?>" class="btn btn-danger">DELETE </td>
                        <td><a href="edit_user.php?edit=<?php echo $u_id;  ?>" class="btn btn-success">EDIT </td>

                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>

</html>