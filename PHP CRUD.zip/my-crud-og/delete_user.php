<?php
include 'config.php';


if(isset($_GET['del'])){

$del_id=$_GET['del'];
$delete="DELETE FROM user WHERE user_id='$del_id'";

$run_delete=mysqli_query($conn,$delete);
if($run_delete===true)
{

// echo " The Data Successfully Deleted.";
header("location:view_user.php");
}

else {
    " Try Again";
}
}
?>