<?php 

session_start();
include_once 'config.php';

    echo "<script> window.open('login.php','_self')</script>";


session_destroy();
