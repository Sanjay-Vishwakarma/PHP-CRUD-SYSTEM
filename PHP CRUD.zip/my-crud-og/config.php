<?php
$conn=mysqli_connect('localhost','root','','mycrudphp');


// if(mysqli_connect_errno()){
// echo " Connection Refused";


// }
// else{
//     echo " Connection Successfully";

// }





// if(!$conn){
// echo " Connection Refused";

// }

// else{

//     echo " Connection Successfully";
// }

?>