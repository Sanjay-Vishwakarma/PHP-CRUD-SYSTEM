<!DOCTYPE html>
<html lang="en">

<head>
    <title>Edit User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <h2>Edit User</h2>
 
        <?php
        include 'config.php';
        if (isset($_GET['edit'])) {
            $edit_id = $_GET['edit'];

            $select = "SELECT * FROM user WHERE user_id='$edit_id'";
            $run = mysqli_query($conn, $select);
            $row_user = mysqli_fetch_array($run);


            $u_name = $row_user['user_name'];
            $u_email = $row_user['user_email'];
            $u_password = $row_user['user_password'];
            $u_image = $row_user['user_image'];
            $u_details = $row_user['user_details'];
        }

        ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" value="<?php echo $u_name; ?>" placeholder="Enter Name" name="user_name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" placeholder="Enter email" value="<?php echo $u_email; ?>" name="user_email">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" placeholder="Enter Password" value="<?php echo $u_password; ?>" name="user_password">
            </div>
            <div class="form-group">
                <label for="Image">Image:</label>
                <input type="file" class="form-control" name="user_image">
            </div>

            <div class="form-group">
                <label for="textarea">Details:</label>
                <textarea input type="text" class="form-control" placeholder="Enter details" value="<?php echo $u_details; ?>" name="user_details"></textarea>
            </div>

            <button type="submit" value="submit" name="insert-btn" class="btn btn-success">Submit</button>
        </form>



        <!-- -----------------------php file for add user------------------------------------- -->



        <?php

        include_once 'config.php';

        if (isset($_POST['insert-btn'])) {

            $euser_name = $_POST['user_name'];
            $euser_email = $_POST['user_email'];
            $euser_password = $_POST['user_password'];
            $eimage = $_FILES['user_image']['name'];
            $eimage_tmp = $_FILES['user_image']['tmp_name'];
            $euser_details = $_POST['user_details'];


            if (empty($eimage) ) {

                $eimage = $u_image;
            }

            $update = "UPDATE user SET  user_name='$euser_name',user_email='$euser_email',user_password='$euser_password',user_image='$eimage',user_details='$euser_details' WHERE user_id='$edit_id'";

            $run_update = mysqli_query($conn, $update);

            if ($run_update === true) {
                echo "Data Inserted";
                move_uploaded_file($eimage_tmp, "upload/$eimage");
            } else {

                echo "Try Again";
            }
        }

        ?>
        <br>
        <br>

        <a href="view_user.php" class="btn btn-primary">View User</a>

    </div>


</body>

</html>